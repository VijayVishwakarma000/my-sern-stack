import React from 'react'

const Home = ({data}) => {
  return (
    <div>Hi {data.username}</div>
  )
}

export default Home
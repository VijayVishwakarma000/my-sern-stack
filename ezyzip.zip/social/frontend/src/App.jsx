import { useState,useEffect, createContext } from 'react'
import './App.css'
import Register from './components/Authentication/Register'
import { Route,Router, Routes } from 'react-router-dom'
import Login from './components/Authentication/Login'
import Navbar from './components/Navbar'
import Home from './Home'
import Error from './components/Error'
import Profile from './components/userComponents/Profile'
import Categories from './Categories'
import Posts from './components/Posts'
import UserPost from './components/UserPost'
export const UserContext = createContext()
function App() {
 const [LoggedIn, setLoggedIn] = useState(false)
 const [userData, setuserData] = useState({})
 const [posts, setposts] = useState({})
 const [postid, setpostid] = useState("")
  useEffect(() => {
    


    fetch('http://localhost:2000/getuser',{
      method:"post",
      headers:{
        "Content-type":"application/json"
      },
      body:JSON.stringify({
        sid:window.localStorage.getItem('sessionid')
      })
    }).then((res)=>{
      res.text().then((t)=>{
          let response = JSON.parse(t)
          if(response.code===1){
            setLoggedIn(true)
            setuserData(response.user[0])
          }else{
            setLoggedIn(false)
          }
      })
    })
  }, [ ])
  

  return (
    <UserContext.Provider value={{setLoggedIn,userData,setuserData,posts, setposts ,setpostid,postid}}>
    <>
    {
      !LoggedIn?
 <Routes>
 <Route path='/' element={<Register/>}/>
 <Route path='/login' element={<Login/>}/>
 <Route path='*' element={<Error/>}/>

 
 </Routes>
 :
<div>
      <Navbar/>
 <Routes>
 <Route path='/' element={<Home data={userData}/>}/>
 <Route path='/profile' element={<Profile data={userData}/>}/>
 <Route path='/categories' element={<Categories data={userData}/>}/>
 <Route path='/categories/threads' element={<Posts />}/>
 <Route path={`/categories/threads/:id`} element={<UserPost postData ={posts} />}/>





 <Route path='*' element={<Error/>}/>
      
 </Routes>
</div>
    }
   

    </>
    </UserContext.Provider>
  )
}

export default App

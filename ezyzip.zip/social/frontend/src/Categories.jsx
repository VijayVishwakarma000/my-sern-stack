import React,{useState,useContext} from 'react'
import { UserContext } from '../src/App';
import { FaLock } from "react-icons/fa";

import {NavLink} from 'react-router-dom'
const Categories = ({data}) => {
  const { setposts} = useContext(UserContext)

  const [Cat, setCat] = useState({
    crackingtools:{
      title:"Cracking Tools",
      posts:[{
        postid:"1",
        username:"John",
        title:"Download latest crack",
        description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
        likes:15,
        dislikes:2,
        comments:[
          {
            postid:"25",
            username:"Ken",
            commentbody:"this is a comment or a bump",
            likes:10,
            dislikes:5,
            
          }
        ]
      }]
    },
    softwares:{
      title:"Softwares",
      posts:[{
        postid:"123",
        username:"Bell",
        title:"Download latest softwares",
        description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
        likes:15,
        dislikes:2,
        comments:[
          {
            postid:"25",
            username:"Roberrt",
            commentbody:"this is a comment or a bump",
            likes:10,
            dislikes:5,
            
          }
        ]
      },
      {
        postid:"250",
        username:"Nelson",
        title:"Download latest projects",
        description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
        likes:15,
        dislikes:2,
        comments:[
          {
            postid:"25",
            username:"Alice",
            commentbody:"this is a comment or a bump",
            likes:10,
            dislikes:5,
            
          }
        ]
      }]
    },
    programming:{
      title:"Programming",
      posts:[{
        postid:"1",
        username:"Jupiter",
        title:" Programming python ",
        description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
        likes:15,
        dislikes:2,
        comments:[
          {
            postid:"25",
            username:"cocomelon",
            commentbody:"this is a comment or a bump",
            likes:10,
            dislikes:5,
            
          }
        ]
      }]
    },

  })
let title = Object.keys(Cat)
 
  return (
    <>
    <div className="postsContainer">
        <div className="mainCategory">
        <div className="registerHeader">
          Categories
        </div>
        <div className='CategoryThreads'>
    {
        title.map((item,id)=>{
       
          return  <div key={id} className="threads">
          <FaLock/>
          <div>
            <span><NavLink onClick={()=>{
               sessionStorage.setItem('postid',item)
                console.log(item)
            }} to={"/categories/threads"}>{Cat[item].title}</NavLink></span>
            <p  >Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum.</p>
          </div>
          <div className='threadDetails'>
  
  
  <div><span>2500</span><span>POSTS</span></div>
  <div><span>2500</span><span>LIKES</span></div>
  <div><span>2500</span><span>COMMENTS</span></div>
  
  </div>
          </div>
        })
    }
       


        
        </div>
        </div>
    </div>
    
    </>
  )
}

export default Categories
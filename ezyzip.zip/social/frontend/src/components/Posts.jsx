import React,{useState,useContext,useEffect,} from 'react'
import { UserContext } from '../App';
import {NavLink,useParams,} from 'react-router-dom'

const Posts = () => {
    const {id} = useParams()
    const {posts,setposts,setpostid,postid} = useContext(UserContext)
    const [postData, setpostData] = useState([])
    const [Cat, setCat] = useState({
        crackingtools:{
          title:"Cracking Tools",
          posts:[{
            postid:"1",
            username:"John",
            title:"Download latest crack",
            description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
            likes:85,
            dislikes:2,
            comments:[
              {
                postid:"25",
                username:"Ken",
                commentbody:"this is a comment or a bump",
                likes:10,
                dislikes:5,
                
              }
            ]
          }]
        },
        softwares:{
          title:"Softwares",
          posts:[{
            postid:"123",
            username:"Bell",
            title:"Download latest softwares",
            description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
            likes:125,
            dislikes:2,
            comments:[
              {
                postid:"25",
                username:"Roberrt",
                commentbody:"this is a comment or a bump",
                likes:10,
                dislikes:5,
                
              }
            ]
          },
          {
            postid:"250",
            username:"Nelson",
            title:"Download latest projects",
            description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
            likes:275,
            dislikes:2,
            comments:[
              {
                postid:"25",
                username:"Alice",
                commentbody:"this is a comment or a bump",
                likes:10,
                dislikes:5,
                
              }
            ]
          }]
        },
        programming:{
          title:"Programming",
          posts:[{
            postid:"1",
            username:"Jupiter",
            title:" Programming python ",
            description:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium corrupti nihil quas sit impedit eum",
            likes:175,
            dislikes:2,
            comments:[
              {
                postid:"25",
                username:"cocomelon",
                commentbody:"this is a comment or a bump",
                likes:10,
                dislikes:5,
                
              }
            ]
          }]
        },
    
      })
    useEffect(() => {
        setpostData(sessionStorage.getItem("postid"))
        
      
    }, [ ])
    
  return (
    <>
    {postData!=""?<div className='postsContainer'>
        <div className="registerHeader">
                    {Cat[postData].title}
                </div>
                <div>

        {
            Cat[postData].posts.map((item,id)=>{
                return <div key={id} className='userPostDetails'>
                    <div className='posts'>
                <div style={{display:"flex", alignItems:"center",gap:"10px"}}>

    <img id='profilePic' src="https://wallpapers-clan.com/wp-content/uploads/2022/08/funny-dog-pfp-18.jpg" alt="profilePic" />
                        <div className='postDetails'>
                            <NavLink  onClick={()=>{
                                setpostid(item.postid)
                                setposts(item)
                            }} to={`/categories/threads/${postid}`}>{item.title}</NavLink>
                            <p >{item.description}</p>
                            </div>
                </div>
                            <div className='postStats'>
  
  
  <div><span>{item.likes}</span><span>LIKES</span></div>
  <div><span>{item.comments.length}</span><span>COMMENTS</span></div>
  
  </div>
                    </div>

                </div>
            })
        }


</div>


    </div>:<div>
        error loading posts please navigate through categories
        </div>}
    </>
  )
}

export default Posts
import React,{useContext} from 'react'
import '/home/toxic/personalProjects/social/frontend/src/App.css'

import { useState } from 'react'
import { MdEmail } from "react-icons/md";
import { FaLock } from "react-icons/fa";
import { FaUser } from "react-icons/fa";
import { NavLink, useNavigate } from 'react-router-dom';
import { UserContext } from '../../App';
const Login = () => {
    const {setLoggedIn,setuserData} = useContext(UserContext)
    const [preloader, setpreloader] = useState(false)
    const [Data, setData] = useState({
        
        username:"",
        password:"",
      })
    
      
      const [ErrorText, setErrorText] = useState("")
      function validateForm(){
        let error = false
    
        if(  Data.username=="" && Data.password==""){
          error=true
          setErrorText("Please fill all the details")
        } else if(Data.username==""){
          error=true
    
          setErrorText("Please fill username")
          
        }else if(Data.password==""){
          error=true
    
          setErrorText("Please fill password")
          
        }
    
    
        return error
      }
      let navigation = useNavigate()
      function login(){
        
        if(validateForm()==false){
            fetch('http://localhost:2000/login',{
                method:"post",
                headers:{
                  "Content-type":"application/json"
                },
                body:JSON.stringify(Data)
              }).then((res)=>{
                res.text().then((t)=>{
                    let response = JSON.parse(t)
                    
                    if(response.code ===  2 ){
                        setErrorText("invalid username or password")
                    }else{
                        window.localStorage.setItem("sessionid",response[0].sessionid)
                        setpreloader(true)
                        setuserData(response[0])
                        setTimeout(() => {
                            setpreloader(false)
                            setLoggedIn(true)
                            navigation('/')
                        }, 1500);
                      
                    }
                   
                    })
              })
            setErrorText("")
        }
      }
  return (
    <>
    {
        preloader ? <div style={{height:"100vh"}}>loading......</div>:<div className='RegisterContainer'>
        <div className='registerBox'>
       <div className="registerHeader">
       <FaLock style={{marginRight:5}} />
       Login
       </div>
       <div className="registerInputs">
           <div>
        
       <div> 
       <label htmlFor="username"><FaUser /> username:</label>
       <input onChange={(e)=>setData({...Data,username:e.target.value})} type="text" name="username"  />
       </div>
       <div> 
       <label htmlFor="password"> <FaLock /> password:</label>
       <input  onChange={(e)=>setData( {...Data,password:e.target.value})} type="password" name="password"  />
       </div>
           </div>
           {ErrorText!=="" ? <div style={{color:"red",textAlign:"center",fontSize:"12px",textTransform:"uppercase"}}>{ErrorText}</div>:""}
           <button onClick={()=>login()}   className='registerBtn'>LOGIN</button>
       </div>
       <div id='loginAlready' >Not registered yet ? <NavLink to={"/"}>Register</NavLink></div>
        </div>
     </div>
    }
    </>

  )
}

export default Login
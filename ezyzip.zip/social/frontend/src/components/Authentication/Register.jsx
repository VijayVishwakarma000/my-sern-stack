import React from 'react'
import '/home/toxic/personalProjects/social/frontend/src/App.css'

import { useState } from 'react'
import { MdEmail } from "react-icons/md";
import { FaLock } from "react-icons/fa";
import { FaUser } from "react-icons/fa";
import { NavLink ,useNavigate} from 'react-router-dom';

const Register = () => {

  const [Data, setData] = useState({
    email:"",
    username:"",
    password:""
  })
  
  const [ErrorText, setErrorText] = useState("")
  function validateForm(){
    let error = false

    if(Data.email=="" && Data.username=="" && Data.password==""){
      error=true
      setErrorText("Please fill all the details")
    }else if(Data.email==""){
      error=true

      setErrorText("Please fill email")

    }else if(Data.username==""){
      error=true

      setErrorText("Please fill username")
      
    }else if(Data.password==""){
      error=true

      setErrorText("Please fill password")
      
    }


    return error
  }
  let navigation = useNavigate()
  function register(){
    if(validateForm()==false){
    setErrorText("")

    fetch('http://localhost:2000/register',{
      
      method:"post",
      headers:{
        "Content-type":"application/json"
      },
      body:JSON.stringify(Data)
    }).then((res)=>{
      res.text().then((t)=>{
        let response = JSON.parse(t)
        if(response.code ===-1){
          setErrorText("User Already Exists!")
        }else{

          navigation('/login')
        }
      })
    })
  }else{

  }

  }

  return (

    <>
      <div className='RegisterContainer'>
         <div className='registerBox'>
        <div className="registerHeader">
        <FaLock style={{marginRight:5}} />
        register
        </div>
        <div className="registerInputs">
            <div>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}> 
        <label htmlFor="email"><MdEmail /> Email:</label>
        <input onChange={(e)=>setData({...Data,email:e.target.value})} type="email" name="email"  />
        </div>
        <div> 
        <label htmlFor="username"><FaUser /> username:</label>
        <input onChange={(e)=>setData({...Data,username:e.target.value})} type="text" name="username"  />
        </div>
        <div> 
        <label htmlFor="password"> <FaLock /> password:</label>
        <input  onChange={(e)=>setData( {...Data,password:e.target.value})} type="password" name="password"  />
        </div>
            </div>
            {ErrorText!=="" ? <div style={{color:"red",textAlign:"center",fontSize:"12px",textTransform:"uppercase"}}>{ErrorText}</div>:""}
            <button type='submit' onClick={()=>register()}   className='registerBtn'>REGISTER</button>
      
        </div>
        <div id='loginAlready' >Already registered ? <NavLink to={"/login"}>login</NavLink></div>
        
         </div>
      </div>
    </>
  )
}

export default Register
import React,{useContext} from 'react'
import { UserContext } from '../App';
import '/home/toxic/personalProjects/social/frontend/src/App.css'
import { FaCaretDown } from "react-icons/fa";

import { NavLink } from 'react-router-dom'

const Navbar = () => {
  const {setLoggedIn,userData} = useContext(UserContext)
  return (
  <header>
     <nav>
      <ul className='navlinks'>
        <li><NavLink to={""}>forum</NavLink></li>
        <li><NavLink to={"/categories"}>categories</NavLink></li>
        <li><NavLink to={""}>livechat</NavLink></li>
        <li><NavLink to={""}>buy/sell</NavLink></li>
      </ul>
      <div>
        <div className='profilePicContainer'>
          <div style={{display:"flex",alignItems:"center",gap:"10px"}}> 
          <img id='profilePic' src="https://wallpapers-clan.com/wp-content/uploads/2022/08/funny-dog-pfp-18.jpg" alt="profilePic" />
          <span ><NavLink to={"/profile"}>{userData.username}<FaCaretDown /> </NavLink></span>
          </div>
          <div className='dropdown'>
          <NavLink to={"/profile"}>profile</NavLink>
          <NavLink to={""}>settings</NavLink>
          </div>
        </div>
        
      </div>
    </nav>
  </header>
  )
}

export default Navbar
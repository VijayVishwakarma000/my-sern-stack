import React from 'react'

const Error = () => {
  return (
    <div>404 page not found</div>
  )
}

export default Error
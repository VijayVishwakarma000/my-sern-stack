import React from 'react'
import '/home/toxic/personalProjects/social/frontend/src/App.css'


const Profile = ({data}) => {
  return (
    <>
        <div className="profileContainer">
            <div className="profileMain">
                <div className="profileDetails">
    <div className='profilepicContainer'>
    <div className="registerHeader">
                    Profile Picture
                </div>
    <img id='profileMainPic' src="https://wallpapers-clan.com/wp-content/uploads/2022/08/funny-dog-pfp-18.jpg" alt="profilePic" />
    </div>       
        <div>
           <div className=''>
           <div className="registerHeader">
                    Profile Details
                </div>
                <div className="userDetails">

           <span>Username: {data.username}</span>
           <span style={{fontWeight:"bolder",}}>About :</span> 
            <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Exercitationem tempore voluptates est saepe quis iure eaque mollitia vero amet fugiat provident esse error officiis vitae, eligendi odit perspiciatis sint pariatur.</p>

           </div>
           </div>

           <div className="postsDetails">
                <div className="registerHeader">
                    statistics
                </div>
                <div className='stats'>


                <div><span>2500</span><span>POSTS</span></div>
                <div><span>2500</span><span>LIKES</span></div>
                <div><span>2500</span><span>COMMENTS</span></div>
                
                </div>
           </div>
        </div>
                </div>
                
                </div>            
        </div>
    </>
  )
}

export default Profile
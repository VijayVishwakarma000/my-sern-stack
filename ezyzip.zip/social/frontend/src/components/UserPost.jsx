import React,{useState,useContext,useEffect} from 'react'
import { UserContext } from '../App';
import {NavLink,useParams,} from 'react-router-dom'

const UserPost = () => {
    const {posts, } = useContext(UserContext)
 
console.log(posts)
  return (
    <div>{posts.postid}</div>
  )
}

export default UserPost
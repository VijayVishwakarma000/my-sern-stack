-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 18, 2024 at 12:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialmedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `postid` varchar(255) DEFAULT NULL,
  `commentid` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `likes` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `postid` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`postid`, `userid`, `category`, `username`, `likes`, `title`, `description`) VALUES
('d72h2d', '5121242f', 'Softwares', 'Doggie Singh', 25, 'how to crack fbi database using doggie', 'this is a post about cracking fbi servers with a doggie');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sessionid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `sessionid`) VALUES
('7e61b105', 'test@gmail.com', 'admin', 'password', '1d42c6fc3d4e5e372e635673'),
('e0b70314', 'test123@gmail.com', 'admin123', 'password', '8ee958ea00ade2f9e409871f'),
('d5bfac4d', 'walter@gmail.com', 'txycc', 'P@ssw0rd', '4a51bba9da20aff8758ac5da'),
('4c7482f4', 'john@gmail.com', 'john', 'doe', '05e2804f38d357fa446ea2e6'),
('5121242f', 'doggie@gmail.com', 'DoggieSingh', 'password', '93ace170bf79ef3f4a59499b');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

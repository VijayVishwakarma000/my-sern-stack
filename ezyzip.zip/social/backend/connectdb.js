const mysql = require("mysql")

let connection =  mysql.createConnection({
    host:"localhost",
    port:3305,
    user:"root",
    password:"",
    database:"socialmedia"
    
})

connection.connect((err)=>{

  
})




module.exports = {
    connection,
   
}



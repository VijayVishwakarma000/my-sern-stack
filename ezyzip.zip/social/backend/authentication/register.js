const express = require('express')
const router = express.Router()
const {connection} = require('../connectdb')
const crypto = require('crypto')

 
function validateEmail(emailAdress){
    let regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

  if (emailAdress.match(regex)) 
    return true; 

   else 
    return false; 
}
const validateUsername = (val) => {
    const usernameRegex = /^[a-z0-9_.]+$/
    return usernameRegex.test(val)
}


router.post('/register',(req,res)=>{
    let {email,username,password} = req.body;
     

         
    let findUser = `SELECT * FROM users WHERE email=? AND username = ? OR email=?`

    connection.query(findUser,[email,username,email],(err,rows,fields)=>{
        if(err){
          res.send({message:err.message})
        }else{
          if(rows.length){
            res.send({message:"User exists!",code:-1})
          }else{
 let query = `INSERT INTO users(id,email,username,password,sessionid) VALUES (?,?,?,?,?)`
     connection.query(query,[crypto.randomBytes(4).toString("hex"),email,username,password,crypto.randomBytes(12).toString("hex")],(err,rows,fields)=>{
      res.send({message:"User Created!"})

})


          }
        }
      


    

})
         


 
 
        

})

module.exports=router

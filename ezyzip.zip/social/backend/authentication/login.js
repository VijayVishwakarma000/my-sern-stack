const express = require('express')
const router = express.Router()
const {connection} = require('../connectdb')


router.post('/login',(req,res)=>{
        let getUsers = "select * from users where username = ? and password = ?";
        connection.query(getUsers,[req.body.username,req.body.password],(err,rows)=>{
            if(rows.length ==0){
                res.send({message:"user not found",code:2})
            }else{
            res.send(rows)
                
            }
        })    


})




module.exports = router
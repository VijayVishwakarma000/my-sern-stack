const express = require('express')
const router = express.Router()
const {connection} = require('../connectdb')


router.post('/getuser',(req,res)=>{

    if(!req.body.sid){
        res.send({message:"user not found",code:-1})

    }else{
        let {sid} = req.body

        let getuser = 'select * from users where sessionId = ?'
        connection.query(getuser,[sid],(err,rows)=>{
            let sessionid = rows[0].sessionid
       
         if(sid==rows[0].sessionid){
            console.log(rows)
             res.send({user:rows, code:1})
     
         }else{
             res.send({message:"user not found",code:2})
     
         }
             
       
        })
    }
 
})


module.exports = router
const express = require('express')
const app = express()
const cors  = require('cors')
const bodyparser = require('body-parser')
require('./connectdb')
const {connection }  = require('./connectdb')
const register = require('./authentication/register')
const login = require('./authentication/login')
const getuser = require('./routes/getusers')
app.use(cors())
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended:true}))
app.use('/',getuser)
app.use('/',register)
app.use('/',login)

 
app.listen(2000,()=>{
    console.log("Listening on port 2000")
})



 


 








